#!/bin/bash

cp "$1/Contents/meshagent_osx64.msh" /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###/###EXECUTABLENAME###.msh
cp "$1/Contents/meshagent_osx64.bin" /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###/###EXECUTABLENAME###
cp "$1/Contents/meshagent_osx64_LaunchDaemon.plist" /Library/LaunchDaemons/###SERVICENAME###.plist
cp "$1/Contents/meshagent_osx64_LaunchAgent.plist" /Library/LaunchAgents/###SERVICENAME###.plist
rm /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###/internal.txt

chown root:wheel /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###
chown root:wheel /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###/###EXECUTABLENAME###
chown root:wheel /Library/LaunchDaemons/###SERVICENAME###.plist
chown root:wheel /Library/LaunchAgents/###SERVICENAME###.plist

chmod 755 /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###
chmod 755 /usr/local/mesh_services/###COMPANYNAME###/###SERVICENAME###/###EXECUTABLENAME###

/bin/launchctl load /Library/LaunchDaemons/###SERVICENAME###.plist
